var sqlite3 = require('sqlite3').verbose();
var express = require('express');
var http = require('http');
var path = require("path");
var bodyParser = require('body-parser');
var helmet = require('helmet');
var rateLimit = require("express-rate-limit");
const port = 8000
const { json } = require('express/lib/response');

const db = new sqlite3.Database(path.join(__dirname,'./database/payroll.db'), sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error("Erro opening database " + err.message);
  }
});

var app = express();
var server = http.createServer(app);

app.use(express.json());

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});



app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, './views')));




app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');

app.get('/', function (req, res) {
  res.render('home.ejs');
});
app.get('404', function (req, res) {
  res.render('404.ejs');
});
app.get('/addEmployee', function (req, res) {
  res.render('addEmployee.ejs');
});
app.get('/addAllowance', function (req, res) {
  res.render('addAllowance.ejs');
});
app.get('/employeeList', function (req, res) {
  db.all(` SELECT * FROM employee`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('employeeList.ejs', { rows });

  });
});
app.get('/overtime', function (req, res) {
  res.render('overtime.ejs');
});
app.get('/deductions', function (req, res) {
  db.all(` SELECT * FROM deductions`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('deductions.ejs', { rows });

  });
});
app.get('/pay', function (req, res) {
  db.all(` SELECT * FROM employee WHERE endDate = 0`, (err, rows) => {
    const month = req.query.month;
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('pay.ejs', {
      rows,
      month
    });

  });
});
app.get('/nKin', function (req, res) {
  db.all(` SELECT * FROM employee`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('nKin.ejs', { rows });

  });
});
app.get('/addDeductions', function (req, res) {
  res.render('addDeductions.ejs');
});
app.get('/companyJobs', function (req, res) {
  db.all(` SELECT * FROM jobCategory`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('companyJobs.ejs', { rows });

  });
});
app.get('/createJobs', function (req, res) {
  res.render('createJobs.ejs');
});
app.get('/allowances', function (req, res) {
  db.all(` SELECT * FROM allowances`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('allowances.ejs', { rows });

  });
});
app.get('/leaveUpdate', function (req, res){
  reqBody = req.body;
  var id = req.query.id;
  var employee = req.query.employee;
  var remaining= req.query.remaining;
  res.render('leaveUpdate.ejs', {remaining, id, employee})
})
app.get('/leaveDays', function (req, res) {
  db.all(` SELECT * FROM leave`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }
    
    res.render('leaveDays.ejs', { rows });

  });
});
app.get('/slip', function (req, res){
  const invoice = req.query.invoiceNo;
  const employee = req.query.employee;
  const title = req.query.title;
  const eId = req.query.eId;
  const date = req.query.date;
  const grossPay = req.query.grossPay;
  const tax = req.query.tax;
  const net = req.query.net;
  const all1 = req.query.all1;
  const all1Am = req.query.all1Am;
  const all2 = req.query.all2;
  const all2Am = req.query.all2Am;
  const all3 = req.query.all3;
  const all3Am = req.query.all3Am;
  const ded1 = req.query.ded1;
  const ded1Am = req.query.ded1Am;
  const ded2 = req.query.ded2;
  const ded2Am = req.query.ded2Am;
  const ded3 = req.query.ded3; 
  const ded3Am = req.query.ded3Am;
  const totalDeductions = +ded3Am + +ded2Am + +ded1Am;
  const totalAllowances = +all1Am + +all2Am + +all3Am;
  const cumulative = +net + +totalAllowances - totalDeductions ;

  const taxAmt = grossPay-net;
  if(employee!= null){
    
  let sql = `SELECT * FROM employee WHERE eId = ?`;

    db.each(sql, [eId], (err, rows) => {
    if (err) {
    throw err;
    }
    let sql1 = `SELECT * FROM leave WHERE employeeId = ?`;

    db.get(sql1, [eId], (err, row) => {
      if (err) {
        return console.error(err.message);
      }
        
      console.log(row)
        res.render('slip.ejs', { 
          row,
          rows,
          invoice,
          employee,
          title,
          eId,
          date,
          grossPay,
          tax,
          net,
          taxAmt,
          all1,
          all1Am,
          all2,
          all2Am,
          all3,
          all3Am,
          ded1,
          ded1Am,
          ded2,
          ded2Am,
          ded3,
          ded3Am,
          cumulative
        });
      });
      });}else{
        res.render('pay.ejs')
      }
})
app.get('/paySlip', function (req, res) {
  db.all(` SELECT * FROM payment ORDER BY pId DESC`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('paySlip.ejs', { rows });

  });
});
app.get('/expenses', function (req,res){
  db.all(`SELECT * FROM expenses ORDER BY eId DESC `, (err, rows)=>{
    if (err){
      res.status(400).json({ "error": err.message});
    }
    res.render('expenses.ejs', { rows })
  })
})
app.get('/company', function (req,res){
  db.all(`SELECT * FROM company ORDER BY cId DESC `, (err, rows)=>{
    if (err){
      res.status(400).json({ "error": err.message});
    }
    res.render('company.ejs', { rows })
  })
})
app.get('/companyQ', function (req,res){
  db.all(`SELECT * FROM company ORDER BY cId DESC `, (err, rows)=>{
    if (err){
      res.status(400).json({ "error": err.message});
    }
    res.render('companyQ.ejs', { rows })
  })
})
app.get('/deleteCompany', function (req, res){
  let sql = `DELETE FROM company
           WHERE cId  = ?`;
 var id = req.query.id;
 db.run(sql, [id], (err) => {
  if (err) {
    return console.error(err.message);
  }
  res.redirect('/company')
});
})
app.get('/addExpense', function (req,res){
  res.render('addExpenses.ejs')
})
app.get('/addCompany', function (req,res){
  res.render('addCompany.ejs')
})
app.get('/payProbation', function (req, res) {
  db.all(` SELECT * FROM employee WHERE onProbation = 1`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }
    res.render('payProbation.ejs', { rows });

  });
});
app.get('/leave', function (req, res) {
  db.all(` SELECT * FROM employee`, (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('leave.ejs', { rows });

  });
});
app.get('/payClients', function (req, res) {
  res.render('payClients.ejs');
});
app.get('/inv', function(req, res){
  let sql = `SELECT * FROM invoices
           WHERE iId  = ?`;
 var id = req.query.id;

// first row only
db.get(sql, [id], (err, row) => {
  if (err) {
    return console.error(err.message);
  }
  res.render('inv.ejs', { row })
});
})
app.get('/invDelete', function (req, res){
  let sql = `DELETE FROM invoices
           WHERE iId  = ?`;
 var id = req.query.id;
 db.run(sql, [id], (err) => {
  if (err) {
    return console.error(err.message);
  }
  res.redirect('/invoices')
});
})
app.get('/quote', function(req, res){
  let sql = `SELECT * FROM quotation
           WHERE iId  = ?`;
 var id = req.query.id;

// first row only
db.get(sql, [id], (err, row) => {
  if (err) {
    return console.error(err.message);
  }
  res.render('inv.ejs', { row })
});
})
app.get('/quoteDelete', function (req, res){
  let sql = `DELETE FROM quotation
           WHERE iId  = ?`;
 var id = req.query.id;
 db.run(sql, [id], (err) => {
  if (err) {
    return console.error(err.message);
  }
  res.redirect('/invoices')
});
})
app.get('/delExpense', function (req, res){
  let sql = `DELETE FROM expenses
           WHERE eId  = ?`;
 var id = req.query.id;
 db.run(sql, [id], (err) => {
  if (err) {
    return console.error(err.message);
  }
  res.redirect('/expenses')
});
})
app.post("/addEmployee/", (req, res, next) => {
  var reqBody = req.body;
  db.run(`INSERT INTO employee (eFname, eLname, eOmangId, dOb, sex, mStatus, nationality, streetName, areaLoc, pBox, town, telFixed, mobileNo, eEmail, jobCategory, nKinFname, nKinLname, nKinRelation, nKinAddress, nKinEmail, employeeBank, bankBranch, accountNo, bankCode, hourlyRate, overTimeRate, startDate, endDate, credentials, nKinPhone, onProbation, probationSalary, workPlace) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [reqBody.fname, reqBody.lname, reqBody.eOmangId, reqBody.dOb, reqBody.sex, reqBody.mStatus, reqBody.nationality, reqBody.streetName, reqBody.areaLoc, reqBody.pBox, reqBody.town, reqBody.telFixed, reqBody.mobileNo, reqBody.eEmail, reqBody.jobCategory, reqBody.nKinFname, reqBody.nKinLname, reqBody.nKinRelation, reqBody.nKinAddress, reqBody.nKinEmail, reqBody.employeeBank, reqBody.bankBranch, reqBody.accountNo, reqBody.bankCode, reqBody.hRate, reqBody.oRate, reqBody.startDate, 0, reqBody.credentials, reqBody.nKinPhone, reqBody.probationStatus, reqBody.probationSalary, reqBody.workPlace],
    function (err, result) {
      if (err) {
        res.status(400).json({ "error": err.message })
        return;
      }
      res.redirect('/employeeList')
    });
})
app.post('/addExpense/', (req, res, next)=>{
  var reqBody = req.body;
  db.run(`INSERT INTO expenses (eName, eAmount, eDate, eDescription) VALUES (?,?,?,?)`,
  [reqBody.eName, reqBody.eAmount, reqBody.eDate, reqBody.eDescription],
  function (err, result){
    if (err){
      res.status(400).json({"error": err.message})
    }
    res.redirect('/expenses')
  })
})
app.post('/addCompany/', (req, res, next)=>{
  var reqBody = req.body;
  db.run(`INSERT INTO company(cName, cAddress, contact, bankDetails, vat, email) VALUES (?,?,?,?,?,?)`,
  [reqBody.company, reqBody.address, reqBody.contact, reqBody.bank, reqBody.vat, reqBody.email],
  function (err, result){
    if (err){
      res.status(400).json({"error": err.message})
    }
    res.redirect('/company')
  })
})
app.post('/addInvoice/', (req, res, next)=>{
  var reqBody = req.body;
  var months = reqBody.imonths;
  var gaurds = reqBody.igaurds;
  var hours = reqBody.ihours;
  var irate = reqBody.irate;
  var company = reqBody.company;

  var amount = (months * gaurds * hours * irate);

  db.run(`INSERT INTO invoices (months, gaurds, hours, rate, amount, idate, fromDate, toDate, sendCompany, bankName, branchName, bankCode, gpoNumber, accNo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  [reqBody.imonths, reqBody.igaurds, reqBody.ihours, reqBody.irate, amount, reqBody.idate, reqBody.ifdate, reqBody.itdate, company, reqBody.bankName, reqBody.branchName, reqBody.bankCode, reqBody.gpoNumber, reqBody.accNo],
  function (err, result){
    if (err){
      res.status(400).json({"error": err.message})
    }
    res.redirect('/invoices')
  })
})
app.post('/addQotation/', (req, res, next)=>{
  var reqBody = req.body;
  var months = reqBody.imonths;
  var gaurds = reqBody.igaurds;
  var hours = reqBody.ihours;
  var irate = reqBody.irate;
  var company = reqBody.company;

  var amount = (months * gaurds * hours * irate);

  db.run(`INSERT INTO quotation (months, gaurds, hours, rate, amount, idate, fromDate, toDate, sendCompany, bankName, branchName, bankCode, gpoNumber, accNo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  [reqBody.imonths, reqBody.igaurds, reqBody.ihours, reqBody.irate, amount, reqBody.idate, reqBody.ifdate, reqBody.itdate, company, reqBody.bankName, reqBody.branchName, reqBody.bankCode, reqBody.gpoNumber, reqBody.accNo],
  function (err, result){
    if (err){
      res.status(400).json({"error": err.message})
    }
    res.redirect('/quotation')
  })
})
app.get('/terminateEmployee', function (req, res, next){
  const id = req.query.id;
  let data = new Date().toISOString().slice(0, 10);
  let sql = `UPDATE employee
            SET endDate = ?
            WHERE eId = ${id}`;

db.run(sql, data, function(err) {
  if (err) {
    return console.error(err.message);
  }
  console.log(`Row(s) updated: ${this.changes}`);
  res.redirect('/employeeList')

});
})
app.get('/viewemployee', function (req, res, next){
  const id = req.query.id;
  let sql = `SELECT * FROM employee WHERE eId = ?`;

  db.each(sql, [id], (err, rows) => {
  if (err) {
  throw err;
  }
  
  res.render('viewemployee.ejs', { rows })

});
})
app.get('/editEmployee', function (req, res, next){
  const id = req.query.id;
  
  res.render('editEmployee.ejs', { id })

});
app.get('/editWork', function (req, res, next){
  const id = req.query.id;
  
  res.render('editWork.ejs', { id })

});
app.get('/deleteEmployee', function (req, res, next){
  const id = req.query.id;
  db.run(`DELETE FROM employee WHERE eId=?`, id, function(err) {
    if (err) {
      return console.error(err.message);
    }
    console.log(`Row(s) deleted ${this.changes}`);

    res.redirect('/employeeList')
  });
})
app.get('/deleteSlip', function (req, res, next){
  const id = req.query.id;
  db.run(`DELETE FROM payment WHERE pId=?`, id, function(err) {
    if (err) {
      return console.error(err.message);
    }
    console.log(`Row(s) deleted ${this.changes}`);

    res.redirect('/paySlip')
  });
})
app.get('/invoices', function (req, res){
  db.all(`SELECT * FROM invoices`, (err, rows)=>{
    if(err){
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('invoices.ejs', {rows})
  })
})
app.get('/addInvoice', function (req, res){
  var company = req.query.company;
 res.render('addInvoice.ejs', { company })
})
app.get('/quotation', function (req, res){
  db.all(`SELECT * FROM quotation`, (err, rows)=>{
    if(err){
      res.status(400).json({ "error": err.message });
      return;
    }

    res.render('quotation.ejs', {rows})
  })
})
app.get('/addQuotation', function (req, res){
  var company = req.query.company;
 res.render('addQuotation.ejs', { company })
})
app.get("/payy", function (req, res){
  var eID = req.query.eId;
  var employee = req.query.employee;
  var hourlyRate = req.query.hRate;
  var oRate = req.query.oRate;
  var job = req.query.job;
  res.render('payy.ejs', {eID, employee, hourlyRate, oRate, job})
})
app.post("/payment/", (req, res, next) => {
  var reqBody = req.body;
  var reqQuery = req.query;
  var today = new Date().toISOString().slice(0, 10);
  var days = reqBody.days;
  var hRate = reqBody.hRate;
  var hDays = reqBody.hDays;
  var gross = (days * hRate * hDays) + (reqBody.oHours * reqBody.oRate);
  var all1Am = reqBody.all1Am;
  var all2Am = reqBody.all2Am;
  var all3Am = reqBody.all3Am;
  var ded1Am = reqBody.ded1Am;
  var ded2Am = reqBody.ded2Am;
  var ded3Am = reqBody.ded3Am;
  var netFinal = net + (all1Am + all2Am + all3Am) - (ded1Am + ded2Am + ded3Am)
  if (gross<=4000){
    var tax = 0;
    var add = 0;payment
  }else if (gross>4000 && gross<=7000) {
    var tax = 5
    var taxAbove = 4000;
    var add = 0;
  }
  else if (gross>7000 && gross<=10000) {
    var tax = 12.5
    var taxAbove = 7000;
    var add = 150;
  }
  else if (gross>10000 && gross<=13000) {
    var tax = 18.75
    var taxAbove = 10000;
    var add = 525;
  } 
  else if(gross>13000) {
    var tax = 25
    var taxAbove = 13000;
    var add = 1087.5;
  }
  if (gross<4000){
    var taxAmt = 0;
  }else{
    var taxAmt = ((gross-taxAbove)*(tax/100)) + add;
  }
  var net = gross - taxAmt;
  db.run(`INSERT INTO payment (eName, eJob, eID, payDate, grossPay, tax, netPay, month, taxAbove, all1, all1Am, all2, all2Am, all3, all3Am, ded1, ded1Am, ded2, ded2Am, ded3, ded3Am, addit, netFinal) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [reqBody.eName, reqBody.eJob, reqBody.eID, today, gross, tax, net, today, taxAbove, reqBody.all1, reqBody.all1Am, reqBody.all2, reqBody.all2Am, reqBody.all3, reqBody.all3Am, reqBody.ded1, reqBody.ded1Am, reqBody.ded2, reqBody.ded2Am, reqBody.all3, reqBody.all3Am, add, netFinal],
    function (err, result) {
      if (err) {
        res.status(400).json({ "error": err.message })
        return;
      }
      res.redirect('/paySlip')
    });
})
app.post("/paymentProbation/", (req, res, next) => {
  var reqBody = req.body;
  var today = new Date().toISOString().slice(0, 10);
  var gross = reqBody.Salary;
  var net = gross - ((reqBody.tax/100)*gross);
  db.run(`INSERT INTO payment (eName, eJob, eID, payDate, grossPay, tax, netPay, month) VALUES (?,?,?,?,?,?,?,?)`,
    [reqBody.eName, reqBody.eJob, reqBody.eID, today, gross, reqBody.tax, net, today],
    function (err, result) {
      if (err) {
        res.status(400).json({ "error": err.message })
        return;
      }
      res.redirect('/paySlip')
    });
})
app.post("/createDeduction/", (req, res, next) => {
  var reqBody = req.body;
  db.run(`INSERT INTO deduction (dedName, dedPercent) VALUES (?,?)`,
    [reqBody.dName, reqBody.amt],
    function (err, result) {
      if (err) {
        res.status(400).json({ "error": err.message })
        return;
      }
      res.redirect('/deductions')
    });
})
app.post("/createJob/", (req, res, next) => {
  var reqBody = req.body;
  db.run(`INSERT INTO jobCategory (jobName, jobSalary, department, jobFixedRate, jobHours, jobDays) VALUES (?,?,?,?,?,?)`,
    [reqBody.title, reqBody.oRate, reqBody.department, reqBody.hRate, reqBody.dayHours, maxDayLeaves],
    function (err, result) {
      if (err) {
        res.status(400).json({ "error": err.message })
        return;
      }
      res.redirect('/allowances') 
    });
})
app.post("/editEmployee", (req, res, next)=>{
  var reqBody = req.body;
  let data =  [reqBody.jobCategory, reqBody.hRate, reqBody.oRate, reqBody.probationStatus, reqBody.probationSalary, reqBody.eID];
  let sql = `UPDATE employee
           SET jobCategory = ?, hourlyRate= ?, overTimeRate =?, onProbation=?, probationSalary=? 
           WHERE eId = ?`;
  
           db.run(sql, data, function(err) {
            if (err) {
              return console.error(err.message);
            }
            console.log(`Row(s) updated: ${this.changes}`);
            res.redirect('/employeeList')
          
          });
})
app.post("/editWork", (req, res, next)=>{
  var reqBody = req.body;
  let data =  [reqBody.workPlace, reqBody.eID];
  let sql = `UPDATE employee
           SET workPlace = ?
           WHERE eId = ?`;
  
           db.run(sql, data, function(err) {
            if (err) {
              return console.error(err.message);
            }
            console.log(`Row(s) updated: ${this.changes}`);
            res.redirect('/employeeList')
          
          });
})
app.post("/createAllowance/", (req, res, next) => {
  var reqBody = req.body;
  db.run(`INSERT INTO allowances (allowanceName, allowanceAmt) VALUES (?,?)`,
    [reqBody.aName, reqBody.amt],
    function (err, result) {
      if (err) {
        res.status(400).json({ "error": err.message })
        return;
      }
      res.redirect('/allowances')
    });
})
app.post("/lApplication/", (req, res, next) => {
  var reqBody = req.body;
  db.run(`INSERT INTO leave (employeeId, maxLeave, leaveDayTaken, rLeave, reason) VALUES (?,?,?,?,?)`,
    [reqBody.employee, reqBody.maxLeave, reqBody.lDays, reqBody.lDays, reqBody.reason],
    function (err, result) {
      if (err) {
        res.status(400).json({ "error": err.message })
        return;
      }
      res.redirect('/leaveDays')
    });
})
app.post("/leaveUpdate/", (req, res, next) => {
  var reqBody= req.body;
  let id = reqBody.id;
  let remaining = reqBody.lRemain;
  let lDays = reqBody.lDays;
  let newDays =(remaining - lDays);
  let data = [newDays, id];
  let sql = `UPDATE leave 
             SET rLeave = ?
             WHERE lId = ?`;
  
    db.run(sql, data, function(err) {
      if (err) {
        return console.error(err.message);
      }
      console.log(`Row(s) updated: , ${this.changes}`, newDays);
      res.redirect('/leaveDays');  
    });
})
app.get('*', function (req, res) {
  res.status(404).render('404.ejs');
});

const setup = async () => {
  app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`)
  })
}
setup()
module.exports = app;