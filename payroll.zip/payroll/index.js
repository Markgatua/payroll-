const { BrowserWindow, app } = require('electron')

require('./app.js')

let mainWindow = null

function main() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 565,
    minWidth: 1024,
    minHeight: 565,
  })
  mainWindow.loadURL(`http://localhost:8000/`)
  mainWindow.on('close', event => {
    mainWindow = null
  })
}

app.on('ready', main)